# Copyright 2025 Canonical Ltd.
# See LICENSE file for licensing details.
"""Postgresql Event Handlers."""
